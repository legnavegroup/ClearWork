# Database setup and migrations

## Docker Compose

Item 02 starts PostgreSQL 17 with a persistent volume. The separate `migrate` service runs `prisma migrate deploy` after the server accepts connections. The API waits for migration success before it starts. Use the same database password when restarting an existing volume.

From `01 - Complete source code`, inspect the migration output and check the applied versions:

```sh
docker compose -p clearwork-submission logs migrate
docker compose -p clearwork-submission exec db psql -U task_platform -d task_platform -c "SELECT migration_name, finished_at FROM _prisma_migrations ORDER BY started_at;"
```

Use your configured username and database name if you changed the defaults. Docker Compose, native PostgreSQL and Kubernetes use separate databases.

## Direct PostgreSQL setup

Install Node.js 24 LTS and PostgreSQL 17. Open interactive `psql` as your local administrator and run:

```sql
CREATE ROLE task_platform LOGIN;
\password task_platform
CREATE DATABASE task_platform OWNER task_platform;
```

In the source project's `apps/api` directory, copy `.env.example` to `.env` and update `DATABASE_URL` and `SESSION_SECRET`. URL-encode special characters in the database password. Then run:

```sh
npm ci
npm run db:generate
npm run db:migrate
npx prisma migrate status
```

In pgAdmin, connect to the native server using the host and port in `DATABASE_URL`. Expand **Databases → task_platform → Schemas → public → Tables**.

## What gets applied

1. Initial schema with users, projects, memberships and tasks.
2. A composite foreign key that keeps task assignments within their project.
3. A session table and indexes for common listing queries.

The [Prisma schema and migrations](../01%20-%20Complete%20source%20code/apps/api/prisma/) are included with the source. Apply the checked-in migrations in order. Preserve the hand-written assignment constraint when reviewing future schema changes. Item 05 covers the Kubernetes migration Job.
