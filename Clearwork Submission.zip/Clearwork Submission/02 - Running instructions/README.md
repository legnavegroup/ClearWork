# Run Clearwork

The runnable project is in [01 - Complete source code](../01%20-%20Complete%20source%20code/README.md). Docker Desktop with Docker Compose v2 is the quickest setup. Leave Docker Desktop running during the demo.

## Windows

Double-click `Start Demo.cmd` in item 04. It checks Docker, creates a local environment file with random values on first run, and waits for database migrations and application readiness. Open [Clearwork](http://localhost:8182/) and [Swagger](http://localhost:8182/api/docs).

## Start from a terminal

1. Open a terminal in `01 - Complete source code`, where `compose.yaml` lives.
2. Copy `.env.example` to `.env` if you do not already have one. Set `POSTGRES_PASSWORD` to a random string of letters and digits and `SESSION_SECRET` to a different random string at least 32 characters long. Add `WEB_PORT=8182`.
3. Run:

   ```sh
   docker compose -p clearwork-submission up --build -d --wait
   ```

4. Open [Clearwork](http://localhost:8182/). Create an account. Follow item 04 for the two-account walkthrough.

The first build needs internet access to download images and npm packages. If port 8182 is occupied, set an unused `WEB_PORT` in `.env`, use the terminal command, and open the new port in your browser.

## Check or stop the app

Run these commands from the same source folder:

```sh
docker compose -p clearwork-submission ps -a
docker compose -p clearwork-submission logs migrate api
docker compose -p clearwork-submission down
```

The database volume persists across stops. For direct Node.js and PostgreSQL development, or for local Kubernetes, use the [source README](../01%20-%20Complete%20source%20code/README.md).
