@echo off
setlocal
pushd "%~dp0..\01 - Complete source code" || exit /b 1
set "PATH=%ProgramFiles%\Docker\Docker\resources\bin;%LOCALAPPDATA%\Programs\DockerDesktop\resources\bin;%PATH%"
docker info --format "{{.ServerVersion}}" >nul 2>&1
if errorlevel 1 (
  echo Start Docker Desktop, wait for its engine, then run this file again.
  popd
  exit /b 1
)
if not exist .env (
  powershell -NoProfile -Command "$ErrorActionPreference = 'Stop'; $db = [guid]::NewGuid().ToString('N'); $secret = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N'); Set-Content -LiteralPath '.env' -Encoding ASCII -Value @('POSTGRES_PASSWORD=' + $db; 'SESSION_SECRET=' + $secret; 'WEB_PORT=8182')"
  if errorlevel 1 (
    popd
    exit /b 1
  )
)
if not defined CLEARWORK_DEMO_PROJECT set "CLEARWORK_DEMO_PROJECT=clearwork-submission"
set "WEB_PORT=8182"
set "BUILD_MODE=--no-build"
docker image inspect clearwork-api:local clearwork-web:local clearwork-tools:local >nul 2>&1
if errorlevel 1 set "BUILD_MODE=--build"
if /i "%~1"=="--build" set "BUILD_MODE=--build"
docker compose -p "%CLEARWORK_DEMO_PROJECT%" up %BUILD_MODE% -d --wait
if errorlevel 1 (
  echo The demo did not start. See item 02 for how to check the service logs.
  popd
  exit /b 1
)
echo.
echo Clearwork: http://localhost:8182/
echo Swagger:   http://localhost:8182/api/docs
popd
exit /b 0
