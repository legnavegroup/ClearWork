# Working demonstration

On Windows, run [Start Demo.cmd](Start%20Demo.cmd) with Docker Desktop open. The launcher reports when the app is ready. On other systems, use item 02's terminal instructions. Both routes run the source included in item 01.

The launcher builds the images on a fresh installation and reuses the three Clearwork images if they are already present. After a source change, run `"Start Demo.cmd" --build` from Command Prompt to rebuild them.

- [Open the app](http://localhost:8182/)
- [Open Swagger](http://localhost:8182/api/docs)
- [Check PostgreSQL readiness](http://localhost:8182/api/health/ready)

## Show the main workflow

1. Create an owner account in a regular browser window. Create a member account with a different email in a private window.
2. As the owner, create a project called **Release preparation** with a short description. Open the project and add the other account by email.
3. Create a task called **Review release notes**. Assign it to the member, set its priority to **High**, and pick a due date.
4. In the member's window, open the project, set the task to **Done**, and find it using the status filter. Verify that the project's completed count increases.
5. Open the dashboard and show the current totals. In Swagger, execute `POST /api/auth/login` with either demo account, then try `GET /api/projects`.

The demo starts with an empty database and saves local records between runs. For cleanup, run the `docker compose … down` command in item 02. The URLs are local to the machine running the demo.
