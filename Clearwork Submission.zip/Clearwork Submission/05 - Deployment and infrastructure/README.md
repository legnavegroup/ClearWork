# Deployment configuration

This folder groups the supplied configuration for review. Run build and deployment commands from [01 - Complete source code](../01%20-%20Complete%20source%20code/README.md), which includes the build contexts and application files.

| File | Role |
| --- | --- |
| `compose.yaml` | Local database, migration, API and web services, plus the optional test service |
| `apps/api/Dockerfile` | API image and separate migration and test image |
| `apps/web/Dockerfile`, `apps/web/nginx.conf` | Static frontend and the reverse proxy for API requests |
| `infra/kubernetes/database.yaml` | Local PostgreSQL service and persistent volume claim |
| `infra/kubernetes/migrate.yaml` | One-off migration Job |
| `infra/kubernetes/app.yaml` | Web and API Deployments, Services, probes and resource settings |
| `infra/kubernetes/secrets.env.example` | Fields required for the local Kubernetes Secret |

For Kubernetes, build the images with `docker compose build`, start the database, finish the migration Job, then deploy the web and API workloads. The [source README](../01%20-%20Complete%20source%20code/README.md) gives the exact commands and port forward for Docker Desktop. Item 06 explains the production deployment tradeoffs.
