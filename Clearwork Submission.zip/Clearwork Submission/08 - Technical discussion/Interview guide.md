# Interview notes

## Five-minute demo

1. Start Compose using the README. Open the app in a regular browser window and a private window, then register a different account in each.
2. As the owner, create a project with a short description. Add the second user by email and assign them a high-priority task with a deadline.
3. As the member, open the project, change the task status and find it again using the status filter. Show the completed and outstanding totals.
4. Open Swagger and show the task update request. Point out the version field, then show the integration test that sends two edits at once and checks for HTTP 409.
5. Show the database migration, Compose health checks and Kubernetes migration Job. Use the verification record to identify the checks that were actually run.

## Decisions to be ready to explain

| Decision | What to discuss |
| --- | --- |
| One backend | Authentication and project rules share the same deployment. Reviewers can run the entire system with three application services and a migration step. |
| Membership checks | A session identifies the caller. Membership answers whether that caller can access a project. Owner checks protect changes to the roster and project details. |
| Assignment constraint | The API returns a readable error while PostgreSQL enforces the rule even if data is changed outside the API. |
| Versioned writes | The database decides whether the submitted version still matches. A stale request cannot overwrite the accepted edit. |
| Releasing a change | Apply the migration first, wait for readiness, then route traffic to the new replicas. Keep schema changes compatible during a rolling release. |

## Debugging practice

Use the browser’s Network panel to check the request and status. A 401 usually means the session is missing, a 404 can indicate a project the caller cannot access, and a 409 means the task version changed. Follow the relevant route in `apps/api/src/work.ts`, reproduce the issue with the smallest example and rerun the appropriate test.

Practise making a small change you can explain. For example, change the task page size and update the API result, the navigation, and the pagination assertions together. The files are linked from the README.
