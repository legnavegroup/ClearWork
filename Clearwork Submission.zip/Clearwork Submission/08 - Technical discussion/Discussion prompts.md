# Technical discussion

Use the [interview walkthrough](Interview%20guide.md) to run the demo, then practise tracing one action from the interface through the API to PostgreSQL.

| Topic | Points to cover |
| --- | --- |
| Architecture | React sends same-origin requests to a NestJS API. Prisma talks to PostgreSQL. One backend keeps deployment simple while authentication and task rules have clear responsibilities. |
| Access control | A session establishes identity. Project membership grants access. Owner checks protect project details and membership changes. |
| Concurrent edits | A task update includes the version the client read. PostgreSQL accepts one write for that version. A competing edit gets HTTP 409 and can reload before retrying. |
| Growing workload | Filter server-side, keep lists paginated and profile real queries. Consider cursor pagination for deep lists and a text index for longer search workloads. |
| Deployments | Compose is convenient for local review and simple single-host operation. Kubernetes can run multiple application replicas and coordinate rolling updates. A production deployment still needs a database backup and recovery plan, HTTPS, monitoring and secure secrets. |

## Live debugging exercise

Change a task in one browser session, then submit an edit from a second session that still has the old version. Inspect the response and explain the HTTP 409. Find the update in `apps/api/src/work.ts`, show the database condition on the expected version, and rerun the integration test. The test sends both updates concurrently and expects one success and one conflict.

## Limits to discuss

The local deployment runs one database instance and was exercised on Docker Desktop. Production traffic capacity, backup restoration and an independent security assessment were outside the verification scope. The rate limiter is per API process and would need shared enforcement across replicas.
