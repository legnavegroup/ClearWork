# Automated tests

The supplied files are grouped here for code review. Run them from the complete source project so the package scripts, TypeScript settings and database are available.

Start the demo in item 04. From `01 - Complete source code`, run:

```sh
docker compose -p clearwork-submission run --rm test npm test -- --runInBand
docker compose -p clearwork-submission run --rm test
```

| Test file | Coverage |
| --- | --- |
| `apps/api/src/work.spec.ts` | Six unit tests for project access, invalid assignment, stale edits, filters and pagination |
| `apps/api/test/integration.cjs` | Three user sessions, role boundaries, database assignment integrity, concurrent task updates, progress, search and dashboard isolation |

The integration suite creates temporary users and projects and cleans up the records it created. If registration is rate limited after repeated runs, the script waits before retrying. See the [verification record](Verification%20record.md) for the checks performed.
