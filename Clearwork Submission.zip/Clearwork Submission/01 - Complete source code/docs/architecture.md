# Architecture

Clearwork is a React application with one NestJS API and one PostgreSQL database. Nginx serves the built frontend and forwards `/api` requests to NestJS. Vite provides the same URL layout in development. Keeping browser requests on one origin simplifies session handling and deployment.

## Data and permissions

| Record | Purpose |
| --- | --- |
| User | Account details and bcrypt password hash |
| Project | Project name and description |
| ProjectMember | A user’s membership and role in a project |
| Task | Project, assignee, status, priority, deadline and edit version |
| session | Expiring PostgreSQL-backed web sessions |

Project creation writes the project and its owner membership together. Every signed-in user can create a project. Owners edit project details and add registered users by email. Members can read the project and create or edit tasks. An outsider receives a 404 for a project they cannot access. Each project has its own roster, so users can work across multiple teams.

The API checks that an assignee belongs to the project. A composite foreign key enforces the same rule in PostgreSQL. Its migration contains hand-written SQL. Review future Prisma schema diffs to preserve that constraint.

Task edits carry the version displayed to the user. A single SQL update checks the project ID, task ID and expected version, then increments the version and returns the updated row. Two requests using the same version produce one successful write and one HTTP 409. A client can reload the task before retrying.

## Security

Authentication regenerates the session ID after login. The cookie is HTTP-only and uses SameSite=Lax. Requests that change data must come from an allowed browser origin. DTO validation rejects unexpected or malformed fields. Helmet supplies API response headers, and Nginx sets a content security policy for the frontend. The API uses an in-process rate limiter. In production, enforce HTTPS and secure cookies, use a shared or edge rate limiter, and give the API database role only the required privileges.

## Queries and growth

Project and task lists use 25-item pages with stable ordering. Task search is restricted to one project and can filter by status. PostgreSQL aggregates progress and dashboard totals. The schema indexes membership lookups and common task access patterns. A practical next step is to profile with representative data, then consider cursor pagination for deep lists and a text index for substring search. Pool limits should account for the total number of API replicas.

## Deployment and failures

Compose starts PostgreSQL and waits for a separate migration container before starting the API. Kubernetes runs migrations as a Job before rolling out the application. The API image contains runtime dependencies and the migration image carries the Prisma CLI. Health endpoints distinguish a live API process from one that can reach PostgreSQL, so a database outage can remove an instance from service without triggering a restart loop.

The local database runs with persistent storage. For production, use managed PostgreSQL with backups and tested recovery, a private network, resource limits and monitoring. Scale the API independently when measurements justify it. Use additive schema changes for rolling releases and test restore and rollback procedures before deployment.
