# Verification record

Docker installs dependencies from the npm lockfiles. The frontend builds to static assets, and the API builds to JavaScript.

## Functional checks

| Check | Coverage |
| --- | --- |
| Six unit tests | Project membership, assignment rules, stale edits, invalid filters and pagination |
| PostgreSQL integration | Three separate sessions, permitted and forbidden project actions, invalid input, database assignment constraint, simultaneous edits, progress counts, dashboard isolation and a 28-record search across two pages |
| Windows development | Migrations applied to the existing local PostgreSQL database and the API integration suite passed |
| Clean ZIP extraction | Extracted the source into a new directory outside the repository. Started Compose with a new database volume. All three migrations ran and the frontend, Swagger and readiness routes responded. Both README test commands passed. |
| Manual browser check | Registered a test account, created a project with its description, created a task, checked progress and searched for the task in the fresh Compose deployment. |
| Local Kubernetes | The migration Job applied the new migration. The API and web rollouts completed. The web, Swagger and database readiness routes responded through the port forward. |

The test suite creates its own accounts and fixtures and removes those records after the run. The pagination exercise verifies the page boundary. It does not measure maximum throughput.

## Dependency audit

On 18 November 2026, `npm audit --omit=dev` reported zero advisories for both lockfiles. The API pins the patched `deepmerge-ts` version under Prisma's configuration package. The full audits still report advisories in development tooling. Nginx ships compiled frontend files. A container check confirmed the API runtime excludes the Prisma CLI, Nest CLI and Jest. A separate image runs migration and test commands.

This is an assessment build. Capacity under production traffic, backup restores, and independent security testing are outside the verified checks.
