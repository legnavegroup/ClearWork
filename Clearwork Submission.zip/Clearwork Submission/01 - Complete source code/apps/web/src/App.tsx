import { useEffect, useState } from "react";
import "./App.css";

type User = { id: string; name: string; email: string };
type Task = {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  version: number;
  dueAt: string | null;
  assignee?: { id: string; name: string } | null;
};
type Project = {
  id: string;
  name: string;
  description: string;
  _count?: { tasks: number; members: number };
  tasks?: Task[];
  members?: { role: string; user: User }[];
  progress?: { total: number; completed: number; outstanding: number };
};

async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`/api${path}`, {
    credentials: "same-origin",
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(
      Array.isArray(body.message)
        ? body.message.join(", ")
        : body.message || "Something went wrong",
    );
  return body as T;
}
const post = (data: unknown): RequestInit => ({
  method: "POST",
  body: JSON.stringify(data),
});

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState(false);
  const [error, setError] = useState("");
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectPage, setProjectPage] = useState(1);
  const [projectTotal, setProjectTotal] = useState(0);
  const [summary, setSummary] = useState({
    projects: 0,
    tasks: 0,
    completed: 0,
    outstanding: 0,
  });
  const [selected, setSelected] = useState<Project | null>(null);
  const [search, setSearch] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [projectName, setProjectName] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [taskName, setTaskName] = useState("");
  const [taskPriority, setTaskPriority] = useState("MEDIUM");
  const [taskAssignee, setTaskAssignee] = useState("");
  const [taskDue, setTaskDue] = useState("");
  const [taskSearch, setTaskSearch] = useState("");
  const [taskStatus, setTaskStatus] = useState("");
  const [taskPage, setTaskPage] = useState(1);
  const [taskTotal, setTaskTotal] = useState(0);
  const [memberEmail, setMemberEmail] = useState("");
  async function refreshProjects(term = "", page = 1) {
    const [result, totals] = await Promise.all([
      api<{ items: Project[]; total: number }>(
        `/projects?search=${encodeURIComponent(term)}&page=${page}`,
      ),
      api<typeof summary>("/dashboard"),
    ]);
    setProjects(result.items);
    setProjectTotal(result.total);
    setProjectPage(page);
    setSummary(totals);
  }
  async function openProject(id: string) {
    const [project, result] = await Promise.all([
      api<Project>(`/projects/${id}`),
      api<{ items: Task[]; total: number }>(`/projects/${id}/tasks?page=1`),
    ]);
    setSelected({ ...project, tasks: result.items });
    setTaskTotal(result.total);
    setTaskPage(1);
    setTaskSearch("");
    setTaskStatus("");
  }
  async function searchTasks(id: string, page: number) {
    const params = new URLSearchParams({
      page: String(page),
      search: taskSearch,
    });
    if (taskStatus) params.set("status", taskStatus);
    const result = await api<{ items: Task[]; total: number }>(
      `/projects/${id}/tasks?${params}`,
    );
    setSelected((current) =>
      current?.id === id ? { ...current, tasks: result.items } : current,
    );
    setTaskTotal(result.total);
    setTaskPage(page);
  }
  async function run(action: () => Promise<void>) {
    setError("");
    try {
      await action();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    }
  }
  useEffect(() => {
    api<User>("/auth/me")
      .then(setUser)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);
  useEffect(() => {
    if (user) void run(() => refreshProjects());
  }, [user]);

  if (loading) return <main className="loading">Loading your workspace…</main>;
  if (!user)
    return (
      <main className="auth-shell">
        <section className="auth-intro">
          <div className="brand">
            <span className="brand-mark">◆</span> clearwork
          </div>
          <div>
            <h1>Projects and tasks</h1>
            <p>Assign work, set deadlines, and see what’s still open.</p>
          </div>
        </section>
        <section className="auth-panel">
          <form
            className="auth-form"
            onSubmit={(e) => {
              e.preventDefault();
              void run(async () => {
                const next = await api<User>(
                  `/auth/${registering ? "register" : "login"}`,
                  post(
                    registering
                      ? { name, email, password }
                      : { email, password },
                  ),
                );
                setUser(next);
                setPassword("");
              });
            }}
          >
            <h2>{registering ? "Create your account" : "Welcome back"}</h2>
            <p className="muted">
              {registering
                ? "Start organizing your team’s work."
                : "Sign in to pick up where you left off."}
            </p>
            {error && (
              <div className="error" role="alert">
                {error}
              </div>
            )}
            {registering && (
              <label>
                Full name
                <input
                  required
                  minLength={2}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                />
              </label>
            )}
            <label>
              Email address
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </label>
            <label>
              Password
              <input
                required
                type="password"
                minLength={registering ? 12 : 1}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={
                  registering ? "At least 12 characters" : "Enter your password"
                }
              />
            </label>
            <button className="primary wide">
              {registering ? "Create account" : "Sign in"} <span>→</span>
            </button>
            <p className="muted switch">
              {registering ? "Already have an account?" : "New here?"}{" "}
              <button
                type="button"
                className="link"
                onClick={() => {
                  setRegistering(!registering);
                  setError("");
                }}
              >
                {registering ? "Sign in" : "Create an account"}
              </button>
            </p>
          </form>
        </section>
      </main>
    );

  const tasks = selected?.tasks ?? [];
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">◆</span> clearwork
        </div>
        <p className="sidebar-label">WORKSPACE</p>
        <button
          className={!selected ? "nav active" : "nav"}
          onClick={() => {
            setSelected(null);
            void run(() => refreshProjects());
          }}
        >
          ▦ <span>Overview</span>
        </button>
        <p className="sidebar-label">
          YOUR PROJECTS <span>{projects.length}</span>
        </p>
        <div className="project-nav">
          {projects.map((p) => (
            <button
              className={selected?.id === p.id ? "nav active" : "nav"}
              key={p.id}
              onClick={() => void run(() => openProject(p.id))}
            >
              <i /> <span>{p.name}</span>
            </button>
          ))}
        </div>
        <div className="sidebar-bottom">
          <div className="avatar">{user.name.charAt(0).toUpperCase()}</div>
          <div>
            <strong>{user.name}</strong>
            <small>{user.email}</small>
          </div>
          <button
            title="Sign out"
            className="signout"
            onClick={() =>
              void run(async () => {
                await api("/auth/logout", post({}));
                setUser(null);
                setSelected(null);
              })
            }
          >
            ↗
          </button>
        </div>
      </aside>
      <main className="content">
        <header>
          <div>
            <p className="breadcrumb">
              WORKSPACE <span>/</span> {selected ? "PROJECT" : "OVERVIEW"}
            </p>
            <h1>
              {selected
                ? selected.name
                : `Good to see you, ${user.name.split(" ")[0]}.`}
            </h1>
            <p className="muted">
              {selected
                ? selected.description || "Your project, all in one place."
                : "Here’s what’s happening across your projects."}
            </p>
          </div>
          <span className="date">
            {new Intl.DateTimeFormat(undefined, { dateStyle: "full" }).format(
              new Date(),
            )}
          </span>
        </header>
        {error && (
          <div className="error" role="alert">
            {error}
          </div>
        )}
        {!selected ? (
          <>
            <div className="stats">
              <article>
                <span>PROJECTS</span>
                <strong>{summary.projects}</strong>
                <small>In your workspace</small>
              </article>
              <article>
                <span>TOTAL TASKS</span>
                <strong>{summary.tasks}</strong>
                <small>Across your projects</small>
              </article>
              <article className="accent-stat">
                <span>COMPLETED TASKS</span>
                <strong>{summary.completed}</strong>
                <small>{summary.outstanding} remaining ↗</small>
              </article>
            </div>
            <section className="section">
              <div className="section-head">
                <div>
                  <h2>
                    Projects <span className="count">{projects.length}</span>
                  </h2>
                </div>
                <form
                  className="inline-form"
                  onSubmit={(e) => {
                    e.preventDefault();
                    void run(() => refreshProjects(search));
                  }}
                >
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search projects"
                    aria-label="Search projects"
                  />
                  <button className="secondary">Search</button>
                </form>
              </div>
              <form
                className="create-project"
                onSubmit={(e) => {
                  e.preventDefault();
                  void run(async () => {
                    await api(
                      "/projects",
                      post({
                        name: projectName,
                        description: projectDescription,
                      }),
                    );
                    setProjectName("");
                    setProjectDescription("");
                    setSearch("");
                    await refreshProjects();
                  });
                }}
              >
                <input
                  required
                  minLength={2}
                  maxLength={120}
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="Project name"
                  aria-label="New project name"
                />
                <input
                  maxLength={2000}
                  value={projectDescription}
                  onChange={(event) =>
                    setProjectDescription(event.target.value)
                  }
                  placeholder="Description (optional)"
                  aria-label="New project description"
                />
                <button className="primary">+ Create project</button>
              </form>
              <div className="project-grid">
                {projects.map((p, index) => (
                  <button
                    className="project-card"
                    key={p.id}
                    onClick={() => void run(() => openProject(p.id))}
                  >
                    <span className="card-top">
                      <span className={`project-icon tone-${index % 3}`}>
                        {p.name.charAt(0).toUpperCase()}
                      </span>
                      <span className="arrow">↗</span>
                    </span>
                    <strong>{p.name}</strong>
                    <p>{p.description}</p>
                    <span className="card-foot">
                      {p._count?.tasks ?? 0} tasks <span>·</span>{" "}
                      {p._count?.members ?? 0} members
                    </span>
                  </button>
                ))}
                {!projects.length && (
                  <div className="empty">
                    No projects found. Create one to get started.
                  </div>
                )}
              </div>
              <div className="pagination">
                <button
                  className="secondary"
                  disabled={projectPage <= 1}
                  onClick={() =>
                    void run(() => refreshProjects(search, projectPage - 1))
                  }
                >
                  Previous
                </button>
                <span>Page {projectPage}</span>
                <button
                  className="secondary"
                  disabled={projectPage * 25 >= projectTotal}
                  onClick={() =>
                    void run(() => refreshProjects(search, projectPage + 1))
                  }
                >
                  Next
                </button>
              </div>
            </section>
          </>
        ) : (
          <>
            <button
              className="link back"
              onClick={() => {
                setSelected(null);
                void run(() => refreshProjects());
              }}
            >
              ← All projects
            </button>
            {selected.members?.some(
              (m) => m.user.id === user.id && m.role === "OWNER",
            ) && (
              <details className="project-settings">
                <summary>Edit project details</summary>
                <form
                  className="create-project"
                  key={selected.id}
                  onSubmit={(e) => {
                    e.preventDefault();
                    const form = new FormData(e.currentTarget);
                    void run(async () => {
                      await api(`/projects/${selected.id}`, {
                        method: "PATCH",
                        body: JSON.stringify({
                          name: form.get("name"),
                          description: form.get("description"),
                        }),
                      });
                      await openProject(selected.id);
                      await refreshProjects();
                    });
                  }}
                >
                  <input
                    name="name"
                    aria-label="Project name"
                    required
                    minLength={2}
                    maxLength={120}
                    defaultValue={selected.name}
                  />
                  <input
                    name="description"
                    aria-label="Project description"
                    maxLength={2000}
                    placeholder="Project description"
                    defaultValue={selected.description}
                  />
                  <button className="secondary">Save changes</button>
                </form>
              </details>
            )}
            <div className="stats">
              <article>
                <span>TOTAL TASKS</span>
                <strong>{selected.progress?.total ?? 0}</strong>
                <small>In this project</small>
              </article>
              <article>
                <span>COMPLETED</span>
                <strong>{selected.progress?.completed ?? 0}</strong>
                <small>{selected.progress?.outstanding ?? 0} outstanding</small>
              </article>
              <article>
                <span>TEAM MEMBERS</span>
                <strong>{selected.members?.length ?? 0}</strong>
                <small>People with access</small>
              </article>
            </div>
            <section className="section">
              <div className="section-head">
                <div>
                  <h2>
                    Tasks <span className="count">{tasks.length}</span>
                  </h2>
                </div>
              </div>
              <form
                className="inline-form task-filters"
                onSubmit={(e) => {
                  e.preventDefault();
                  void run(() => searchTasks(selected.id, 1));
                }}
              >
                <input
                  aria-label="Search tasks"
                  value={taskSearch}
                  onChange={(e) => setTaskSearch(e.target.value)}
                  placeholder="Search tasks"
                />
                <select
                  aria-label="Filter by status"
                  value={taskStatus}
                  onChange={(e) => setTaskStatus(e.target.value)}
                >
                  <option value="">All statuses</option>
                  <option value="TODO">To do</option>
                  <option value="IN_PROGRESS">In progress</option>
                  <option value="DONE">Done</option>
                </select>
                <button className="secondary">Filter</button>
              </form>
              <form
                className="create-project"
                onSubmit={(e) => {
                  e.preventDefault();
                  void run(async () => {
                    await api(
                      `/projects/${selected.id}/tasks`,
                      post({
                        title: taskName,
                        priority: taskPriority,
                        ...(taskAssignee ? { assigneeId: taskAssignee } : {}),
                        ...(taskDue
                          ? {
                              dueAt: new Date(
                                `${taskDue}T12:00:00`,
                              ).toISOString(),
                            }
                          : {}),
                      }),
                    );
                    setTaskName("");
                    setTaskAssignee("");
                    setTaskDue("");
                    await openProject(selected.id);
                  });
                }}
              >
                <input
                  required
                  maxLength={200}
                  value={taskName}
                  onChange={(e) => setTaskName(e.target.value)}
                  placeholder="What needs to be done?"
                  aria-label="New task title"
                />
                <select
                  aria-label="Task priority"
                  value={taskPriority}
                  onChange={(e) => setTaskPriority(e.target.value)}
                >
                  <option value="LOW">Low</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="HIGH">High</option>
                  <option value="URGENT">Urgent</option>
                </select>
                <select
                  aria-label="Assign task to"
                  value={taskAssignee}
                  onChange={(e) => setTaskAssignee(e.target.value)}
                >
                  <option value="">Unassigned</option>
                  {selected.members?.map((m) => (
                    <option key={m.user.id} value={m.user.id}>
                      {m.user.name}
                    </option>
                  ))}
                </select>
                <input
                  aria-label="Due date"
                  type="date"
                  value={taskDue}
                  onChange={(e) => setTaskDue(e.target.value)}
                />
                <button className="primary">+ Add task</button>
              </form>
              <div className="task-list">
                {tasks.map((t) => (
                  <div className="task-row" key={t.id}>
                    <div>
                      <strong>{t.title}</strong>
                      <small>
                        {t.priority.toLowerCase()} priority ·{" "}
                        {t.assignee?.name || "Unassigned"}
                        {t.dueAt
                          ? ` · Due ${new Date(t.dueAt).toLocaleDateString()}`
                          : ""}
                      </small>
                    </div>
                    <select
                      aria-label={`Status for ${t.title}`}
                      value={t.status}
                      onChange={(e) => {
                        const status = e.target.value;
                        void run(async () => {
                          await api(`/projects/${selected.id}/tasks/${t.id}`, {
                            method: "PATCH",
                            body: JSON.stringify({
                              status,
                              version: t.version,
                            }),
                          });
                          await openProject(selected.id);
                        });
                      }}
                    >
                      <option value="TODO">To do</option>
                      <option value="IN_PROGRESS">In progress</option>
                      <option value="DONE">Done</option>
                    </select>
                    <details className="task-edit" key={t.version}>
                      <summary>Edit</summary>
                      <form
                        className="edit-fields"
                        onSubmit={(e) => {
                          e.preventDefault();
                          const form = new FormData(e.currentTarget);
                          const due = String(form.get("dueAt") || "");
                          void run(async () => {
                            await api(
                              `/projects/${selected.id}/tasks/${t.id}`,
                              {
                                method: "PATCH",
                                body: JSON.stringify({
                                  version: t.version,
                                  title: form.get("title"),
                                  description: form.get("description"),
                                  priority: form.get("priority"),
                                  assigneeId: form.get("assigneeId") || null,
                                  dueAt: due
                                    ? new Date(`${due}T12:00:00`).toISOString()
                                    : null,
                                }),
                              },
                            );
                            await openProject(selected.id);
                          });
                        }}
                      >
                        <label>
                          Title
                          <input
                            name="title"
                            required
                            maxLength={200}
                            defaultValue={t.title}
                          />
                        </label>
                        <label>
                          Description
                          <textarea
                            name="description"
                            maxLength={5000}
                            defaultValue={t.description}
                          />
                        </label>
                        <label>
                          Priority
                          <select name="priority" defaultValue={t.priority}>
                            <option value="LOW">Low</option>
                            <option value="MEDIUM">Medium</option>
                            <option value="HIGH">High</option>
                            <option value="URGENT">Urgent</option>
                          </select>
                        </label>
                        <label>
                          Assignee
                          <select
                            name="assigneeId"
                            defaultValue={t.assignee?.id || ""}
                          >
                            <option value="">Unassigned</option>
                            {selected.members?.map((m) => (
                              <option key={m.user.id} value={m.user.id}>
                                {m.user.name}
                              </option>
                            ))}
                          </select>
                        </label>
                        <label>
                          Due date
                          <input
                            name="dueAt"
                            type="date"
                            defaultValue={t.dueAt?.slice(0, 10) || ""}
                          />
                        </label>
                        <button className="secondary">Save task</button>
                      </form>
                    </details>
                  </div>
                ))}
                {!tasks.length && (
                  <div className="empty">
                    No tasks match. Adjust the filter or add a task.
                  </div>
                )}
              </div>
              <div className="pagination">
                <button
                  className="secondary"
                  disabled={taskPage <= 1}
                  onClick={() =>
                    void run(() => searchTasks(selected.id, taskPage - 1))
                  }
                >
                  Previous
                </button>
                <span>Page {taskPage}</span>
                <button
                  className="secondary"
                  disabled={taskPage * 25 >= taskTotal}
                  onClick={() =>
                    void run(() => searchTasks(selected.id, taskPage + 1))
                  }
                >
                  Next
                </button>
              </div>
            </section>
            <section className="section">
              <div className="section-head">
                <div>
                  <h2>Project members</h2>
                </div>
              </div>
              <div className="members">
                {selected.members?.map((m) => (
                  <span key={m.user.id}>
                    {m.user.name} <small>{m.role.toLowerCase()}</small>
                  </span>
                ))}
              </div>
              {selected.members?.some(
                (m) => m.user.id === user.id && m.role === "OWNER",
              ) && (
                <form
                  className="create-project"
                  onSubmit={(e) => {
                    e.preventDefault();
                    void run(async () => {
                      await api(
                        `/projects/${selected.id}/members`,
                        post({ email: memberEmail }),
                      );
                      setMemberEmail("");
                      await openProject(selected.id);
                    });
                  }}
                >
                  <input
                    required
                    type="email"
                    value={memberEmail}
                    onChange={(e) => setMemberEmail(e.target.value)}
                    placeholder="Existing user’s email"
                    aria-label="Member email"
                  />
                  <button className="secondary">Add member</button>
                </form>
              )}
            </section>
          </>
        )}
      </main>
    </div>
  );
}
export default App;
