-- A task can only be assigned to a member of its own project.
-- A null assignee is allowed; PostgreSQL skips the foreign-key check for nulls.
ALTER TABLE "Task"
  ADD CONSTRAINT "Task_project_assignee_membership_fkey"
  FOREIGN KEY ("projectId", "assigneeId")
  REFERENCES "ProjectMember" ("projectId", "userId")
  ON DELETE NO ACTION ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED;
