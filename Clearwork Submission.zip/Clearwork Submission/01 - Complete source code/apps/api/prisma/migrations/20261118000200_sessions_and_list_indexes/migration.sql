-- Existing development databases may already have a session table.
CREATE TABLE IF NOT EXISTS "session" (
  "sid" varchar PRIMARY KEY,
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL
);

CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");
CREATE INDEX "Project_updatedAt_id_idx" ON "Project" ("updatedAt", "id");
CREATE INDEX "Task_projectId_createdAt_id_idx" ON "Task" ("projectId", "createdAt", "id");
