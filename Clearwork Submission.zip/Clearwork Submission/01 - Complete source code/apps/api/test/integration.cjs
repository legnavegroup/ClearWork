// Run only against a disposable or local development database and a running API.
const assert = require("node:assert/strict");
const { randomUUID } = require("node:crypto");
const { existsSync } = require("node:fs");
const { PrismaClient } = require("@prisma/client");
if (existsSync(".env")) process.loadEnvFile(".env");

const url = new URL(process.env.DATABASE_URL);
const base = process.env.TEST_API_URL || "http://localhost:3000/api";
const baseUrl = new URL(base);
const local = ["localhost", "127.0.0.1"];
const compose = url.hostname === "db" && baseUrl.origin === "http://api:3000";
if (
  !compose &&
  !(local.includes(url.hostname) && local.includes(baseUrl.hostname))
) {
  throw new Error(
    "Run these tests against local services or the bundled Compose project.",
  );
}
const db = new PrismaClient();
const origin = process.env.TEST_ORIGIN || "http://localhost:5173";
const ids = { users: [], projects: [] };
const sessions = [];

async function request(method, path, data, cookie, requestOrigin = origin) {
  const response = await fetch(base + path, {
    signal: AbortSignal.timeout(10000),
    method,
    headers: {
      "Content-Type": "application/json",
      ...(cookie ? { Cookie: cookie } : {}),
      ...(requestOrigin ? { Origin: requestOrigin } : {}),
    },
    ...(data === undefined ? {} : { body: JSON.stringify(data) }),
  });
  const body = await response.json();
  return {
    status: response.status,
    body,
    cookie: response.headers.get("set-cookie")?.split(";")[0],
  };
}

async function register(label) {
  const email = `${label.toLowerCase().replace(/[^a-z0-9]/g, "")}-${randomUUID()}@example.test`;
  let result = await request("POST", "/auth/register", {
    name: label,
    email,
    password: "integration-test-password-123",
  });
  if (result.status === 429) {
    console.log(
      "Registration rate limit reached; waiting for the one-minute window to reset.",
    );
    await new Promise((resolve) => setTimeout(resolve, 61000));
    result = await request("POST", "/auth/register", {
      name: label,
      email,
      password: "integration-test-password-123",
    });
  }
  assert.equal(result.status, 201, JSON.stringify(result.body));
  ids.users.push(result.body.id);
  assert.ok(result.cookie, "Registration should set a session cookie");
  sessions.push(result.cookie);
  return { id: result.body.id, email, cookie: result.cookie };
}

(async () => {
  try {
    assert.equal((await request("GET", "/projects")).status, 401);
    assert.equal(
      (
        await request(
          "POST",
          "/auth/login",
          {},
          undefined,
          "http://untrusted.example",
        )
      ).status,
      403,
    );
    const owner = await register("Owner Test");
    const member = await register("Member Test");
    const outsider = await register("Outside Test");
    const project = await request(
      "POST",
      "/projects",
      { name: "Integration project" },
      owner.cookie,
    );
    assert.equal(project.status, 201);
    ids.projects.push(project.body.id);
    const root = `/projects/${project.body.id}`;
    assert.equal(
      (await request("GET", root, undefined, outsider.cookie)).status,
      404,
    );
    assert.equal(
      (
        await request(
          "GET",
          "/projects?search=a&search=b",
          undefined,
          owner.cookie,
        )
      ).status,
      400,
    );
    assert.equal(
      (await request("PATCH", root, { name: null }, owner.cookie)).status,
      400,
    );
    assert.equal(
      (
        await request(
          "POST",
          `${root}/members`,
          { email: member.email },
          owner.cookie,
        )
      ).status,
      201,
    );
    assert.equal(
      (
        await request(
          "POST",
          `${root}/members`,
          { email: outsider.email },
          member.cookie,
        )
      ).status,
      404,
    );
    await assert.rejects(
      db.task.create({
        data: {
          title: "Invalid assignment",
          projectId: project.body.id,
          assigneeId: ids.users[2],
        },
      }),
      (error) => error.code === "P2003",
    );
    const task = await request(
      "POST",
      `${root}/tasks`,
      { title: "Prepare review", assigneeId: ids.users[1], priority: "HIGH" },
      owner.cookie,
    );
    assert.equal(task.status, 201, JSON.stringify(task.body));
    const taskPath = `${root}/tasks/${task.body.id}`;
    const edits = await Promise.all([
      request("PATCH", taskPath, { version: 1, status: "DONE" }, member.cookie),
      request("PATCH", taskPath, { version: 1, status: "DONE" }, owner.cookie),
    ]);
    assert.deepEqual(edits.map((edit) => edit.status).sort(), [200, 409]);
    const projectDetails = await request("GET", root, undefined, owner.cookie);
    assert.deepEqual(projectDetails.body.progress, {
      total: 1,
      completed: 1,
      outstanding: 0,
    });
    const results = await request(
      "GET",
      `${root}/tasks?search=review&status=DONE&page=1`,
      undefined,
      owner.cookie,
    );
    assert.equal(results.status, 200);
    assert.equal(results.body.total, 1);
    await db.task.createMany({
      data: Array.from({ length: 28 }, (_, index) => ({
        projectId: project.body.id,
        title: `Pagination fixture ${index + 1}`,
      })),
    });
    const query = `${root}/tasks?search=Pagination`;
    const first = await request(
      "GET",
      `${query}&page=1`,
      undefined,
      owner.cookie,
    );
    const second = await request(
      "GET",
      `${query}&page=2`,
      undefined,
      owner.cookie,
    );
    assert.equal(first.body.total, 28);
    assert.equal(first.body.items.length, 25);
    assert.equal(second.body.items.length, 3);
    assert.equal(
      new Set(
        [...first.body.items, ...second.body.items].map((item) => item.id),
      ).size,
      28,
    );
    const dashboard = await request(
      "GET",
      "/dashboard",
      undefined,
      outsider.cookie,
    );
    assert.equal(dashboard.body.projects, 0);
    console.log(
      "Integration checks passed: authentication, origin protection, membership, ownership, task updates, search and dashboard isolation.",
    );
  } finally {
    await Promise.allSettled(
      sessions.map((cookie) => request("POST", "/auth/logout", {}, cookie)),
    );
    if (ids.projects.length)
      await db.project.deleteMany({ where: { id: { in: ids.projects } } });
    if (ids.users.length)
      await db.user.deleteMany({ where: { id: { in: ids.users } } });
    await db.$disconnect();
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
