import {
  Controller,
  Get,
  Module,
  ServiceUnavailableException,
} from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import { APP_GUARD } from "@nestjs/core";
import {
  SkipThrottle,
  ThrottlerGuard,
  ThrottlerModule,
} from "@nestjs/throttler";
import { PrismaService } from "./prisma.service";
import { AuthController, AuthGuard } from "./auth";
import { DashboardController, WorkController, WorkService } from "./work";

@ApiTags("Health")
@SkipThrottle()
@Controller("health")
export class HealthController {
  constructor(private readonly db: PrismaService) {}
  @Get()
  @ApiOperation({
    summary: "Check whether the API process is running",
    description:
      "This liveness endpoint does not check the database connection.",
  })
  check() {
    return { status: "ok" };
  }
  @Get("ready")
  @ApiOperation({
    summary: "Check whether the API can reach PostgreSQL",
    description:
      "Used by the readiness probe to avoid sending traffic to an instance without database access.",
  })
  async readiness() {
    try {
      await this.db.$queryRaw`SELECT 1`;
      return { status: "ready" };
    } catch {
      throw new ServiceUnavailableException("Database is unavailable");
    }
  }
}

@Module({
  imports: [ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }])],
  controllers: [
    HealthController,
    AuthController,
    WorkController,
    DashboardController,
  ],
  providers: [
    PrismaService,
    AuthGuard,
    WorkService,
    { provide: APP_GUARD, useClass: ThrottlerGuard },
  ],
})
export class AppModule {}
