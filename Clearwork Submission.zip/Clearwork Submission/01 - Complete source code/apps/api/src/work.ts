import {
  BadRequestException,
  Body,
  ConflictException,
  Controller,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from "@nestjs/common";
import {
  ApiCookieAuth,
  ApiOperation,
  ApiProperty,
  ApiPropertyOptional,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from "@nestjs/swagger";
import { TaskPriority, TaskStatus } from "@prisma/client";
import {
  IsDateString,
  IsEmail,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Matches,
  MaxLength,
  Min,
  ValidateIf,
} from "class-validator";
import type { Request } from "express";
import { AuthGuard } from "./auth";
import { PrismaService } from "./prisma.service";

class ProjectInput {
  @ApiProperty() @IsString() @Length(2, 120) name: string;
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(2000)
  description?: string;
}
class UpdateProjectInput {
  @ApiPropertyOptional()
  @ValidateIf((_, value) => value !== undefined)
  @IsString()
  @Length(2, 120)
  name?: string;
  @ApiPropertyOptional()
  @ValidateIf((_, value) => value !== undefined)
  @IsString()
  @MaxLength(2000)
  description?: string;
}
class MemberInput {
  @ApiProperty() @IsEmail() @MaxLength(254) email: string;
}
class CreateTaskInput {
  @ApiProperty() @IsString() @Length(1, 200) title: string;
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(5000)
  description?: string;
  @ApiPropertyOptional({ enum: TaskPriority })
  @ValidateIf((_, value) => value !== undefined)
  @IsEnum(TaskPriority)
  priority?: TaskPriority;
  @ApiPropertyOptional({ type: String, format: "date-time", nullable: true })
  @IsOptional()
  @IsDateString({ strict: true })
  dueAt?: string | null;
  @ApiPropertyOptional() @IsOptional() @IsUUID() assigneeId?: string;
}
class UpdateTaskInput {
  @ApiProperty({
    description: "Version last read by the client; rejects stale updates.",
  })
  @IsInt()
  @Min(1)
  version: number;
  @ApiPropertyOptional()
  @ValidateIf((_, value) => value !== undefined)
  @IsString()
  @Length(1, 200)
  title?: string;
  @ApiPropertyOptional()
  @ValidateIf((_, value) => value !== undefined)
  @IsString()
  @MaxLength(5000)
  description?: string;
  @ApiPropertyOptional({ enum: TaskStatus })
  @ValidateIf((_, value) => value !== undefined)
  @IsEnum(TaskStatus)
  status?: TaskStatus;
  @ApiPropertyOptional({ enum: TaskPriority })
  @ValidateIf((_, value) => value !== undefined)
  @IsEnum(TaskPriority)
  priority?: TaskPriority;
  @ApiPropertyOptional({ type: String, format: "date-time", nullable: true })
  @IsOptional()
  @IsDateString({ strict: true })
  dueAt?: string | null;
  @ApiPropertyOptional({ type: String, format: "uuid", nullable: true })
  @IsOptional()
  @IsUUID()
  assigneeId?: string | null;
}

class PageQuery {
  @IsOptional() @IsString() @MaxLength(100) search?: string;
  @IsOptional() @IsString() @Matches(/^\d{1,5}$/) page?: string;
}

class TaskQuery extends PageQuery {
  @IsOptional() @IsEnum(TaskStatus) status?: TaskStatus;
}

@Injectable()
export class WorkService {
  constructor(private readonly db: PrismaService) {}

  async member(projectId: string, userId: string, owner = false) {
    const membership = await this.db.projectMember.findUnique({
      where: { projectId_userId: { projectId, userId } },
    });
    if (!membership || (owner && membership.role !== "OWNER"))
      throw new NotFoundException("Project not found");
    return membership;
  }

  async list(userId: string, search = "", page = 1) {
    if (!Number.isInteger(page) || page < 1 || page > 10000)
      throw new BadRequestException("Invalid page number");
    const where = {
      members: { some: { userId } },
      ...(search
        ? {
            name: {
              contains: search.slice(0, 100),
              mode: "insensitive" as const,
            },
          }
        : {}),
    };
    const [items, total] = await Promise.all([
      this.db.project.findMany({
        where,
        orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
        skip: (page - 1) * 25,
        take: 25,
        include: { _count: { select: { tasks: true, members: true } } },
      }),
      this.db.project.count({ where }),
    ]);
    return { items, total, page, pageSize: 25 };
  }

  async dashboard(userId: string) {
    const where = { project: { members: { some: { userId } } } };
    const [projects, counts] = await Promise.all([
      this.db.project.count({ where: { members: { some: { userId } } } }),
      this.db.task.groupBy({ by: ["status"], where, _count: { _all: true } }),
    ]);
    const tasks = counts.reduce((sum, item) => sum + item._count._all, 0);
    const completed =
      counts.find((item) => item.status === "DONE")?._count._all ?? 0;
    return { projects, tasks, completed, outstanding: tasks - completed };
  }

  async create(userId: string, input: ProjectInput) {
    if (input.name.trim().length < 2)
      throw new BadRequestException(
        "Project name must contain at least two non-space characters",
      );
    return this.db.project.create({
      data: {
        name: input.name.trim(),
        description: input.description?.trim() ?? "",
        members: { create: { userId, role: "OWNER" } },
      },
    });
  }

  async details(projectId: string, userId: string) {
    await this.member(projectId, userId);
    const [project, counts] = await Promise.all([
      this.db.project.findUnique({
        where: { id: projectId },
        include: {
          members: {
            include: {
              user: { select: { id: true, name: true, email: true } },
            },
          },
        },
      }),
      this.db.task.groupBy({
        by: ["status"],
        where: { projectId },
        _count: { _all: true },
      }),
    ]);
    if (!project) throw new NotFoundException("Project not found");
    const total = counts.reduce((sum, item) => sum + item._count._all, 0);
    const completed =
      counts.find((item) => item.status === "DONE")?._count._all ?? 0;
    return {
      ...project,
      progress: { total, completed, outstanding: total - completed },
    };
  }

  async updateProject(
    projectId: string,
    userId: string,
    input: UpdateProjectInput,
  ) {
    await this.member(projectId, userId, true);
    if (input.name !== undefined && input.name.trim().length < 2)
      throw new BadRequestException(
        "Project name must contain at least two non-space characters",
      );
    return this.db.project.update({
      where: { id: projectId },
      data: {
        ...(input.name === undefined ? {} : { name: input.name.trim() }),
        ...(input.description === undefined
          ? {}
          : { description: input.description.trim() }),
      },
    });
  }

  async addMember(projectId: string, userId: string, email: string) {
    await this.member(projectId, userId, true);
    const user = await this.db.user.findUnique({
      where: { email: email.trim().toLowerCase() },
      select: { id: true },
    });
    if (!user) throw new NotFoundException("User not found");
    return this.db.projectMember.upsert({
      where: { projectId_userId: { projectId, userId: user.id } },
      update: {},
      create: { projectId, userId: user.id },
    });
  }

  async createTask(projectId: string, userId: string, input: CreateTaskInput) {
    await this.member(projectId, userId);
    if (!input.title.trim())
      throw new BadRequestException("Task title cannot be empty");
    if (input.assigneeId) await this.member(projectId, input.assigneeId);
    return this.db.task.create({
      data: {
        projectId,
        title: input.title.trim(),
        description: input.description?.trim() ?? "",
        priority: input.priority,
        dueAt: input.dueAt ? new Date(input.dueAt) : undefined,
        assigneeId: input.assigneeId,
      },
    });
  }

  async listTasks(
    projectId: string,
    userId: string,
    search: string,
    status: string,
    page: number,
  ) {
    await this.member(projectId, userId);
    if (!Number.isInteger(page) || page < 1 || page > 10000)
      throw new BadRequestException("Invalid page number");
    if (status && !Object.values(TaskStatus).includes(status as TaskStatus))
      throw new BadRequestException("Invalid task status");
    const where = {
      projectId,
      ...(search
        ? {
            title: {
              contains: search.slice(0, 100),
              mode: "insensitive" as const,
            },
          }
        : {}),
      ...(status ? { status: status as TaskStatus } : {}),
    };
    const [items, total] = await Promise.all([
      this.db.task.findMany({
        where,
        skip: (page - 1) * 25,
        take: 25,
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        include: { assignee: { select: { id: true, name: true } } },
      }),
      this.db.task.count({ where }),
    ]);
    return { items, total, page, pageSize: 25 };
  }

  async updateTask(
    projectId: string,
    taskId: string,
    userId: string,
    input: UpdateTaskInput,
  ) {
    await this.member(projectId, userId);
    if (input.title !== undefined && !input.title.trim())
      throw new BadRequestException("Task title cannot be empty");
    if (input.assigneeId) await this.member(projectId, input.assigneeId);
    const { version, dueAt, ...data } = input;
    const [updated] = await this.db.task.updateManyAndReturn({
      where: { id: taskId, projectId, version },
      data: {
        ...data,
        title: data.title?.trim(),
        ...(dueAt === undefined
          ? {}
          : { dueAt: dueAt ? new Date(dueAt) : null }),
        version: { increment: 1 },
      },
    });
    if (!updated) {
      if (
        !(await this.db.task.findFirst({
          where: { id: taskId, projectId },
          select: { id: true },
        }))
      )
        throw new NotFoundException("Task not found");
      throw new ConflictException(
        "This task was changed by another user. Refresh and try again.",
      );
    }
    return updated;
  }
}

@ApiTags("Dashboard")
@ApiCookieAuth()
@UseGuards(AuthGuard)
@Controller("dashboard")
export class DashboardController {
  constructor(private readonly work: WorkService) {}
  @Get()
  @ApiOperation({
    summary: "Summarize work visible to the current user",
    description:
      "Counts include only projects of which the current user is a member.",
  })
  @ApiResponse({
    status: 200,
    description: "Project, task, completed and outstanding totals.",
  })
  @ApiResponse({ status: 401, description: "No authenticated session." })
  summary(@Req() req: Request) {
    return this.work.dashboard(req.session.userId!);
  }
}

@ApiTags("Projects and tasks")
@ApiCookieAuth()
@UseGuards(AuthGuard)
@Controller("projects")
export class WorkController {
  constructor(private readonly work: WorkService) {}
  @Get()
  @ApiOperation({
    summary: "List projects available to the current user",
    description:
      "Results are scoped to project membership, searchable by name, and paginated in groups of 25.",
  })
  @ApiQuery({
    name: "search",
    required: false,
    description: "Case-insensitive project-name search.",
  })
  @ApiQuery({
    name: "page",
    required: false,
    type: Number,
    description: "One-based page number; defaults to 1.",
  })
  @ApiResponse({
    status: 200,
    description: "An object containing items, total, page and pageSize.",
  })
  @ApiResponse({ status: 401, description: "No authenticated session." })
  list(@Req() req: Request, @Query() query: PageQuery) {
    return this.work.list(
      req.session.userId!,
      query.search,
      Number(query.page ?? 1),
    );
  }
  @Post()
  @ApiOperation({ summary: "Create a project and become its owner" })
  create(@Req() req: Request, @Body() input: ProjectInput) {
    return this.work.create(req.session.userId!, input);
  }
  @Get(":projectId")
  @ApiOperation({
    summary: "View project members and task progress",
    description:
      "Returns project details, members, and totals for completed and outstanding work. Use the task-list endpoint for paginated tasks.",
  })
  details(@Req() req: Request, @Param("projectId", ParseUUIDPipe) id: string) {
    return this.work.details(id, req.session.userId!);
  }
  @Patch(":projectId")
  @ApiOperation({
    summary: "Update project details",
    description: "Only the project owner may update the project.",
  })
  updateProject(
    @Req() req: Request,
    @Param("projectId", ParseUUIDPipe) id: string,
    @Body() input: UpdateProjectInput,
  ) {
    return this.work.updateProject(id, req.session.userId!, input);
  }
  @Post(":projectId/members")
  @ApiOperation({
    summary: "Add an existing user by email",
    description: "Only the project owner can add members.",
  })
  member(
    @Req() req: Request,
    @Param("projectId", ParseUUIDPipe) id: string,
    @Body() input: MemberInput,
  ) {
    return this.work.addMember(id, req.session.userId!, input.email);
  }
  @Post(":projectId/tasks")
  @ApiOperation({
    summary: "Create a task for this project",
    description: "An assignee must already be a project member.",
  })
  task(
    @Req() req: Request,
    @Param("projectId", ParseUUIDPipe) id: string,
    @Body() input: CreateTaskInput,
  ) {
    return this.work.createTask(id, req.session.userId!, input);
  }
  @Get(":projectId/tasks")
  @ApiOperation({
    summary: "Search and paginate tasks",
    description:
      "Filters by title and status. Only project members can access results.",
  })
  @ApiQuery({
    name: "search",
    required: false,
    description: "Case-insensitive title search.",
  })
  @ApiQuery({ name: "status", required: false, enum: TaskStatus })
  @ApiQuery({
    name: "page",
    required: false,
    type: Number,
    description: "One-based page; 25 tasks per page.",
  })
  @ApiResponse({
    status: 200,
    description: "An object containing items, total, page and pageSize.",
  })
  @ApiResponse({
    status: 404,
    description: "Project not found or inaccessible.",
  })
  tasks(
    @Req() req: Request,
    @Param("projectId", ParseUUIDPipe) id: string,
    @Query() query: TaskQuery,
  ) {
    return this.work.listTasks(
      id,
      req.session.userId!,
      query.search ?? "",
      query.status ?? "",
      Number(query.page ?? 1),
    );
  }
  @Patch(":projectId/tasks/:taskId")
  @ApiOperation({
    summary: "Update a task",
    description:
      "Send the version last read; concurrent updates return HTTP 409.",
  })
  @ApiResponse({
    status: 200,
    description: "Updated task and incremented version.",
  })
  @ApiResponse({
    status: 409,
    description: "The task was changed after the supplied version was read.",
  })
  @ApiResponse({
    status: 404,
    description: "Project or task is not found or is inaccessible.",
  })
  update(
    @Req() req: Request,
    @Param("projectId", ParseUUIDPipe) id: string,
    @Param("taskId", ParseUUIDPipe) task: string,
    @Body() input: UpdateTaskInput,
  ) {
    return this.work.updateTask(id, task, req.session.userId!, input);
  }
}
