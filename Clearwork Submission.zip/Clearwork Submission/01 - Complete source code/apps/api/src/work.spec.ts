import {
  BadRequestException,
  ConflictException,
  NotFoundException,
} from "@nestjs/common";
import { WorkService } from "./work";

describe("project access and task updates", () => {
  const db = {
    project: { findMany: jest.fn(), count: jest.fn() },
    projectMember: { findUnique: jest.fn() },
    task: {
      updateManyAndReturn: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      count: jest.fn(),
    },
  };
  const service = new WorkService(db as any);

  beforeEach(() => jest.resetAllMocks());

  it("blocks access to a project for a non-member", async () => {
    db.projectMember.findUnique.mockResolvedValue(null);
    await expect(service.member("project", "outsider")).rejects.toBeInstanceOf(
      NotFoundException,
    );
  });

  it("rejects updates using an old version", async () => {
    db.projectMember.findUnique.mockResolvedValue({ role: "MEMBER" });
    db.task.updateManyAndReturn.mockResolvedValue([]);
    db.task.findFirst.mockResolvedValue({ id: "task" });
    await expect(
      service.updateTask("project", "task", "member", {
        version: 1,
        title: "Updated",
      }),
    ).rejects.toBeInstanceOf(ConflictException);
  });

  it("rejects an assignee who is not a project member", async () => {
    db.projectMember.findUnique
      .mockResolvedValueOnce({ role: "MEMBER" })
      .mockResolvedValueOnce(null);
    await expect(
      service.createTask("project", "member", {
        title: "Task",
        assigneeId: "outsider",
      }),
    ).rejects.toBeInstanceOf(NotFoundException);
  });

  it("rejects invalid task status filters before querying tasks", async () => {
    db.projectMember.findUnique.mockResolvedValue({ role: "MEMBER" });
    await expect(
      service.listTasks("project", "member", "", "INVALID", 1),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(db.task.findMany).not.toHaveBeenCalled();
  });

  it("limits task search to the requested project and page", async () => {
    db.projectMember.findUnique.mockResolvedValue({ role: "MEMBER" });
    db.task.findMany.mockResolvedValue([]);
    db.task.count.mockResolvedValue(31);
    const result = await service.listTasks(
      "project",
      "member",
      "report",
      "TODO",
      2,
    );
    expect(result).toEqual({ items: [], total: 31, page: 2, pageSize: 25 });
    expect(db.task.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          projectId: "project",
          status: "TODO",
        }),
        skip: 25,
        take: 25,
      }),
    );
  });

  it("limits project listing to memberships and returns the requested page", async () => {
    db.project.findMany.mockResolvedValue([]);
    db.project.count.mockResolvedValue(30);
    const result = await service.list("member", "launch", 2);
    expect(result).toEqual({ items: [], total: 30, page: 2, pageSize: 25 });
    expect(db.project.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          members: { some: { userId: "member" } },
        }),
        skip: 25,
        take: 25,
      }),
    );
  });
});
