import {
  BadRequestException,
  Body,
  CanActivate,
  ConflictException,
  Controller,
  ExecutionContext,
  Get,
  Injectable,
  Post,
  Req,
  UnauthorizedException,
  UseGuards,
} from "@nestjs/common";
import {
  ApiBody,
  ApiCookieAuth,
  ApiOperation,
  ApiProperty,
  ApiTags,
} from "@nestjs/swagger";
import {
  IsEmail,
  IsString,
  Length,
  MaxLength,
  MinLength,
} from "class-validator";
import { compare, hash } from "bcryptjs";
import type { Request } from "express";
import { PrismaService } from "./prisma.service";
import { Throttle } from "@nestjs/throttler";

declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}

class RegisterDto {
  @ApiProperty({ example: "Ada Okoro" })
  @IsString()
  @Length(2, 100)
  name: string;
  @ApiProperty({ example: "ada@example.com" })
  @IsEmail()
  @MaxLength(254)
  email: string;
  @ApiProperty({ minLength: 12, writeOnly: true })
  @IsString()
  @MinLength(12)
  @MaxLength(72)
  password: string;
}
class LoginDto {
  @ApiProperty({ example: "ada@example.com" })
  @IsEmail()
  @MaxLength(254)
  email: string;
  @ApiProperty({ writeOnly: true }) @IsString() @MaxLength(72) password: string;
}

@Injectable()
export class AuthGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    if (!request.session?.userId)
      throw new UnauthorizedException("Please sign in");
    return true;
  }
}

function renewSession(request: Request): Promise<void> {
  return new Promise((resolve, reject) =>
    request.session.regenerate((error) => (error ? reject(error) : resolve())),
  );
}
function saveSession(request: Request): Promise<void> {
  return new Promise((resolve, reject) =>
    request.session.save((error) => (error ? reject(error) : resolve())),
  );
}

@ApiTags("Authentication")
@Controller("auth")
export class AuthController {
  constructor(private readonly db: PrismaService) {}

  @Post("register")
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  @ApiOperation({ summary: "Create an account and start a session" })
  @ApiBody({ type: RegisterDto })
  async register(@Body() input: RegisterDto, @Req() req: Request) {
    const email = input.email.trim().toLowerCase();
    if (input.name.trim().length < 2)
      throw new BadRequestException(
        "Name must contain at least two non-space characters",
      );
    if (Buffer.byteLength(input.password, "utf8") > 72)
      throw new BadRequestException("Password must not exceed 72 UTF-8 bytes");
    if (await this.db.user.findUnique({ where: { email } }))
      throw new ConflictException("An account with that email already exists");
    const passwordHash = await hash(input.password, 12);
    let user;
    try {
      user = await this.db.user.create({
        data: { name: input.name.trim(), email, passwordHash },
        select: { id: true, name: true, email: true },
      });
    } catch (error: any) {
      if (error?.code === "P2002")
        throw new ConflictException(
          "An account with that email already exists",
        );
      throw error;
    }
    await renewSession(req);
    req.session.userId = user.id;
    await saveSession(req);
    return user;
  }

  @Post("login")
  @Throttle({ default: { limit: 5, ttl: 60000 } })
  @ApiOperation({ summary: "Sign in using email and password" })
  @ApiBody({ type: LoginDto })
  async login(@Body() input: LoginDto, @Req() req: Request) {
    if (Buffer.byteLength(input.password, "utf8") > 72)
      throw new UnauthorizedException("Invalid email or password");
    const user = await this.db.user.findUnique({
      where: { email: input.email.trim().toLowerCase() },
    });
    if (!user || !(await compare(input.password, user.passwordHash)))
      throw new UnauthorizedException("Invalid email or password");
    await renewSession(req);
    req.session.userId = user.id;
    await saveSession(req);
    return { id: user.id, name: user.name, email: user.email };
  }

  @Get("me")
  @UseGuards(AuthGuard)
  @ApiCookieAuth()
  @ApiOperation({ summary: "Get the signed-in account" })
  async me(@Req() req: Request) {
    const user = await this.db.user.findUnique({
      where: { id: req.session.userId },
      select: { id: true, name: true, email: true },
    });
    if (!user) throw new UnauthorizedException("Please sign in");
    return user;
  }

  @Post("logout")
  @UseGuards(AuthGuard)
  @ApiCookieAuth()
  @ApiOperation({ summary: "End the current session" })
  async logout(@Req() req: Request) {
    await new Promise<void>((resolve, reject) =>
      req.session.destroy((error) => (error ? reject(error) : resolve())),
    );
    return { success: true };
  }
}
