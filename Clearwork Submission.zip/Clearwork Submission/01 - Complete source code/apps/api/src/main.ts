import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { Logger, ValidationPipe } from "@nestjs/common";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import helmet from "helmet";
import session from "express-session";
import type { NextFunction, Request, Response } from "express";
import { existsSync } from "fs";
import { Pool } from "pg";
import { AppModule } from "./app.module";

async function bootstrap() {
  if (existsSync(".env")) process.loadEnvFile(".env");
  if (
    !process.env.DATABASE_URL ||
    !process.env.SESSION_SECRET ||
    process.env.SESSION_SECRET.length < 32
  ) {
    throw new Error(
      "DATABASE_URL and a SESSION_SECRET of at least 32 characters are required",
    );
  }
  const app = await NestFactory.create(AppModule);
  app.enableShutdownHooks();
  if (process.env.TRUST_PROXY === "1")
    app.getHttpAdapter().getInstance().set("trust proxy", 1);
  const headers = helmet();
  const swaggerHeaders = helmet({ contentSecurityPolicy: false });
  app.use((req: Request, res: Response, next: NextFunction) => {
    const swagger =
      req.path === "/api/docs" || req.path.startsWith("/api/docs/");
    return (swagger ? swaggerHeaders : headers)(req, res, next);
  });
  const allowedOrigins = new Set(
    (
      process.env.ALLOWED_ORIGINS ||
      "http://localhost:5173,http://localhost:3000"
    )
      .split(",")
      .map((s) => s.trim()),
  );
  app.use((req: Request, res: Response, next: NextFunction) => {
    if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) {
      const origin = req.get("origin");
      if (!origin || !allowedOrigins.has(origin)) {
        res.status(403).json({ message: "Request origin is not allowed" });
        return;
      }
    }
    next();
  });
  const PgStore = require("connect-pg-simple")(session);
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    connectionTimeoutMillis: 3000,
  });
  pool.on("error", () =>
    Logger.error("An idle session database connection failed", "SessionStore"),
  );
  const cookieName = process.env.COOKIE_NAME || "clearwork-local.sid";
  app.use(
    session({
      name: cookieName,
      secret: process.env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      store: new PgStore({ pool }),
      cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.COOKIE_SECURE
          ? process.env.COOKIE_SECURE === "true"
          : process.env.NODE_ENV === "production",
        maxAge: 8 * 60 * 60 * 1000,
      },
    }),
  );
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );
  app.setGlobalPrefix("api");
  const config = new DocumentBuilder()
    .setTitle("Project and Task Management API")
    .setDescription(
      "Run POST /api/auth/register or POST /api/auth/login first. Your browser sends the session cookie with later requests. Scripts must supply the cookie and an approved Origin for writes.",
    )
    .addCookieAuth(cookieName)
    .setVersion("0.1.0")
    .build();
  SwaggerModule.setup(
    "api/docs",
    app,
    SwaggerModule.createDocument(app, config),
  );
  await app.listen(
    Number(process.env.PORT || 3000),
    process.env.HOST || "127.0.0.1",
  );
}
void bootstrap();
