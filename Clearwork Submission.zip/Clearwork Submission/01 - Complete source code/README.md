# Clearwork

Clearwork is a project and task management application. Project owners create projects and add members. Members can assign work to one another, set priorities and deadlines, and track completion. Search and dashboard totals are scoped to the signed-in user’s projects.

## Run the demo

You need Docker with Docker Compose v2. On Windows or macOS, start Docker Desktop. Extract the ZIP and open a terminal in the directory containing `compose.yaml`.

Copy `.env.example` to `.env` and replace `POSTGRES_PASSWORD` and `SESSION_SECRET` with different random values. Use letters and digits for the database password so it works as written in the connection URL. Use at least 32 characters for the session secret. Here is the PowerShell setup if you are starting without a root `.env` file.

```powershell
if (!(Test-Path .env)) {
  $dbPassword = [guid]::NewGuid().ToString('N')
  $sessionSecret = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
  Set-Content -Path .env -Value @("POSTGRES_PASSWORD=$dbPassword", "SESSION_SECRET=$sessionSecret")
}
docker compose up --build -d --wait
```

- [Open Clearwork](http://localhost:8080/) and create an account.
- [Open Swagger](http://localhost:8080/api/docs). Execute `POST /api/auth/login` in Swagger first. The browser sends the session cookie on subsequent requests.
- [Check readiness](http://localhost:8080/api/health/ready). A successful response means the API can reach PostgreSQL.

The first start downloads the base images and installs npm dependencies from the lockfiles. Compose starts PostgreSQL, runs the migrations, then starts the API and web service. Only the web service is published on the host. If port 8080 is in use, set `WEB_PORT=8180` in `.env` and use that port in the links above.

Create a second account in a private browser window. In the first account, create a project and add the second user by email. Assign a task to that user. In the second window, open the project, change the task status, then check the project and dashboard counts.

```sh
docker compose ps -a
docker compose logs migrate api
docker compose down
```

The PostgreSQL volume survives `docker compose down`. Keep the same database password when restarting with that volume. Changing the environment file alone does not change the password of an existing PostgreSQL role.

## Run the tests

With the Compose stack running, execute these commands from the same directory.

```sh
docker compose run --rm test npm test -- --runInBand
docker compose run --rm test
```

The first command runs Jest. The second runs the API against PostgreSQL with three temporary accounts. It checks authentication, origin validation, role boundaries, the assignment constraint, simultaneous edits, project totals, search and pagination. It removes the records it creates. Repeated runs may wait for the registration rate limit.

## Develop without Docker

Use Node.js 24 LTS and PostgreSQL 17. Create a PostgreSQL login and an empty database called `task_platform` owned by that login. For example, in interactive `psql` as the local administrator:

```sql
CREATE ROLE task_platform LOGIN;
\password task_platform
CREATE DATABASE task_platform OWNER task_platform;
```

Copy `apps/api/.env.example` to `apps/api/.env`. Set `DATABASE_URL` to match the login and database you just created. URL-encode any special characters in the password. Set a random `SESSION_SECRET` of at least 32 characters. Keep both environment files private.

In `apps/api`:

```sh
npm ci
npm run db:generate
npm run db:migrate
npm run start:dev
```

In another terminal in `apps/web`:

```sh
npm ci
npm run dev
```

The frontend is at [localhost:5173](http://localhost:5173/) and Swagger is at [localhost:3000/api/docs](http://localhost:3000/api/docs). Vite proxies `/api` to NestJS. Run `npm test -- --runInBand` and `npm run test:integration` from `apps/api`. Start the API and apply migrations before running integration tests. The Compose, Kubernetes and native setups each use their own database.

## Deploy to local Kubernetes

Enable Kubernetes in Docker Desktop. The manifests use images built by `docker compose build` and tested on Docker Desktop with kind. For a different cluster, make the three images available to its nodes and update the image references.

Copy `infra/kubernetes/secrets.env.example` to `.env.kubernetes`. Replace the password in both places with the same random value and give Kubernetes its own session secret. On a fresh cluster, run:

```sh
docker compose build
kubectl --context docker-desktop create namespace clearwork-assessment
kubectl --context docker-desktop -n clearwork-assessment create secret generic task-platform-secrets --from-env-file=.env.kubernetes
kubectl --context docker-desktop -n clearwork-assessment apply -f infra/kubernetes/database.yaml
kubectl --context docker-desktop -n clearwork-assessment rollout status deployment/postgres --timeout=180s
kubectl --context docker-desktop -n clearwork-assessment apply -f infra/kubernetes/migrate.yaml
kubectl --context docker-desktop -n clearwork-assessment wait --for=condition=complete job/clearwork-migrate --timeout=180s
kubectl --context docker-desktop -n clearwork-assessment apply -f infra/kubernetes/app.yaml
kubectl --context docker-desktop -n clearwork-assessment rollout status deployment/api --timeout=180s
kubectl --context docker-desktop -n clearwork-assessment rollout status deployment/web --timeout=180s
kubectl --context docker-desktop -n clearwork-assessment port-forward service/web 8081:80
```

Open [localhost:8081](http://localhost:8081/) while the last command is running. After a web rollout, restart the port forward if it was attached to a replaced pod. For later releases, build and tag new images, use a new migration Job name for each release, wait for it to complete, and then roll out the app. Keep the existing persistent volume. For production, terminate TLS at the ingress, enable secure cookies, and set the allowed browser origin. Enable `TRUST_PROXY=1` only if all requests reach the API through one trusted proxy that controls forwarding headers.

## Code and review notes

- `apps/api/src/auth.ts` handles registration, login and sessions.
- `apps/api/src/work.ts` holds project and task rules and their HTTP routes.
- `apps/api/prisma/migrations` contains the database setup. Apply migrations in order through Prisma.
- `apps/web/src/App.tsx` is the project workspace.
- [Architecture decisions](docs/architecture.md), [verification record](docs/verification.md), and [interview guide](docs/interview-guide.md).

The deployment examples are for a local assessment. Production would also need shared rate limits, managed backups and recovery, monitoring, and capacity testing. Project membership defines access and assignment. Each project can have its own members, and a person can belong to more than one project.
